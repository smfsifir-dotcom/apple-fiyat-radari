import re

path = "android/app/src/main/AndroidManifest.xml"
with open(path, "r", encoding="utf-8") as f:
    xml = f.read()

perms = (
    '    <uses-permission android:name="android.permission.INTERNET"/>\n'
    '    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>\n'
)

if 'android.permission.INTERNET' not in xml:
    xml = xml.replace('<application', perms + '    <application', 1)

xml = re.sub(
    r'android:label="[^"]*"',
    'android:label="Apple Fiyat Radari"',
    xml,
    count=1,
)

if 'android:usesCleartextTraffic' not in xml:
    xml = xml.replace(
        '<application',
        '<application\n        android:usesCleartextTraffic="true"',
        1,
    )

https_queries = (
    '        <intent>\n'
    '            <action android:name="android.intent.action.VIEW" />\n'
    '            <data android:scheme="https" />\n'
    '        </intent>\n'
    '        <intent>\n'
    '            <action android:name="android.intent.action.VIEW" />\n'
    '            <data android:scheme="http" />\n'
    '        </intent>\n'
)

if '<data android:scheme="https"' not in xml:
    if '<queries>' in xml:
        xml = xml.replace('</queries>', https_queries + '    </queries>', 1)
    else:
        queries_block = '    <queries>\n' + https_queries + '    </queries>\n'
        xml = xml.replace('</manifest>', queries_block + '</manifest>', 1)

with open(path, "w", encoding="utf-8") as f:
    f.write(xml)

print("AndroidManifest.xml basariyla guncellendi.")
