import '../models/apple_catalog.dart';

class RawListing {
  final String title;
  final int priceTl;
  final String url;
  final String source;
  final String sellerOrCity;

  const RawListing({
    required this.title,
    required this.priceTl,
    required this.url,
    required this.source,
    this.sellerOrCity = '',
  });
}

class AiFilteredResult {
  final RawListing? bestListing;
  final int totalScanned;
  final int eliminatedCount;
  final DateTime scannedAt;

  const AiFilteredResult({
    required this.bestListing,
    required this.totalScanned,
    required this.eliminatedCount,
    required this.scannedAt,
  });
}

class AiListingFilter {
  static const List<String> _commonAccessoryBlocklist = [
    'kilif',
    'kılıf',
    'kapak',
    'ekran koruyucu',
    'kirilmaz cam',
    'kırılmaz cam',
    'sarj aleti',
    'şarj aleti',
    'sarj kablosu',
    'şarj kablosu',
    'adaptor',
    'adaptör',
    'kordon',
    'kayis',
    'kayış',
    'stant',
    'stand',
    'canta',
    'çanta',
    'bos kutu',
    'boş kutu',
    'sadece kutu',
    'kutu sadece',
    'kalem ucu',
    'sticker',
    'etiket',
    'hub',
    'cevirici',
    'çevirici',
  ];

  static const List<String> _usedRiskBlocklist = [
    'yurt disi',
    'yurtdışı',
    'yurt dışı',
    'yurtdisi',
    'kayitsiz',
    'kayıtsız',
    'pasaport kayit',
    'pasaport kayıt',
    'imei kayitsiz',
    'kirik',
    'kırık',
    'catlak',
    'çatlak',
    'arizali',
    'arızalı',
    'bozuk',
    'parca',
    'parça',
    'yedek parca',
    'hurda',
    'icloud',
    'kilitli',
    'bypass',
    'mdm',
    'replika',
    'cakma',
    'çakma',
    'hasarli',
    'hasarlı',
    'sivi temas',
    'sıvı temas',
    'tamirli',
    'anakart',
    'ekran degisen',
    'ekran değişen',
    'face id calismiyor',
    'face id çalışmıyor',
    'true tone yok',
    'ekrani yok',
    'ekranı yok',
    'calismiyor',
    'çalışmıyor',
    'toplama',
    'gevey',
  ];

  static String _norm(String s) {
    return s
        .toLowerCase()
        .replaceAll('İ', 'i')
        .replaceAll('ı', 'i')
        .replaceAll('ğ', 'g')
        .replaceAll('ü', 'u')
        .replaceAll('ş', 's')
        .replaceAll('ö', 'o')
        .replaceAll('ç', 'c')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static AiFilteredResult evaluate({
    required List<RawListing> listings,
    required AppleProduct product,
    required SpecVariant variant,
    required bool isUsed,
    required bool trOnly,
  }) {
    final minPrice =
        isUsed ? product.minUsedSanity(variant) : product.minNewSanity(variant);
    final maxPrice =
        isUsed ? product.maxUsedSanity(variant) : product.maxNewSanity(variant);

    final List<RawListing> clean = [];
    int eliminated = 0;

    for (final item in listings) {
      if (item.priceTl < minPrice || item.priceTl > maxPrice) {
        eliminated++;
        continue;
      }

      final t = _norm(item.title);
      if (t.length < 6 || item.url.isEmpty) {
        eliminated++;
        continue;
      }

      bool blocked = false;
      for (final kw in _commonAccessoryBlocklist) {
        if (t.contains(_norm(kw))) {
          blocked = true;
          break;
        }
      }
      if (blocked) {
        eliminated++;
        continue;
      }

      if (isUsed) {
        for (final kw in _usedRiskBlocklist) {
          if (!trOnly &&
              (kw.contains('yurt') ||
                  kw.contains('kayit') ||
                  kw.contains('pasaport') ||
                  kw.contains('imei'))) {
            continue;
          }
          if (t.contains(_norm(kw))) {
            blocked = true;
            break;
          }
        }
        if (blocked) {
          eliminated++;
          continue;
        }
      }

      bool missingCore = false;
      for (final req in product.mustContainTokens) {
        if (!t.contains(_norm(req))) {
          missingCore = true;
          break;
        }
      }
      if (missingCore) {
        eliminated++;
        continue;
      }

      bool wrongModel = false;
      for (final bad in product.forbidModelTokens) {
        final b = _norm(bad);
        if (b.isNotEmpty &&
            RegExp('(^|\\W)${RegExp.escape(b)}(\\W|\$)').hasMatch(t)) {
          wrongModel = true;
          break;
        }
      }
      if (wrongModel) {
        eliminated++;
        continue;
      }

      bool wrongSpec = false;
      for (final tok in variant.requiredTokens) {
        final nTok = _norm(tok);
        if (nTok == '16' &&
            (t.contains('8 gb') || t.contains('8gb')) &&
            !t.contains('16 gb') &&
            !t.contains('16gb')) {
          wrongSpec = true;
          break;
        }
        if (nTok == '24' && !t.contains('24 gb') && !t.contains('24gb')) {
          wrongSpec = true;
          break;
        }
        if (nTok == '512' &&
            (t.contains('256') || t.contains('128')) &&
            !t.contains('512')) {
          wrongSpec = true;
          break;
        }
        if (nTok == '256' && t.contains('128') && !t.contains('256')) {
          wrongSpec = true;
          break;
        }
        if (nTok == '1tb' && !t.contains('1 tb') && !t.contains('1tb')) {
          wrongSpec = true;
          break;
        }
      }
      if (wrongSpec) {
        eliminated++;
        continue;
      }

      clean.add(item);
    }

    clean.sort((a, b) => a.priceTl.compareTo(b.priceTl));

    RawListing? winner;
    if (clean.isNotEmpty) {
      if (isUsed && clean.length >= 4) {
        final median = clean[clean.length ~/ 2].priceTl;
        for (final c in clean) {
          if (c.priceTl >= (median * 0.74).round()) {
            winner = c;
            break;
          } else {
            eliminated++;
          }
        }
        winner ??= clean.first;
      } else {
        winner = clean.first;
      }
    }

    return AiFilteredResult(
      bestListing: winner,
      totalScanned: listings.length,
      eliminatedCount: eliminated,
      scannedAt: DateTime.now(),
    );
  }
}
