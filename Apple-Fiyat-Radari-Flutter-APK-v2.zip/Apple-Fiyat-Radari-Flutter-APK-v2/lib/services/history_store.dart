import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class PricePoint {
  final int timestampMs;
  final int priceTl;

  const PricePoint({
    required this.timestampMs,
    required this.priceTl,
  });

  Map<String, dynamic> toJson() => {
        't': timestampMs,
        'p': priceTl,
      };

  factory PricePoint.fromJson(Map<String, dynamic> m) => PricePoint(
        timestampMs: (m['t'] as num).toInt(),
        priceTl: (m['p'] as num).toInt(),
      );
}

class HistoryStore {
  static const _themeKey = 'apple_radar_dark_theme';

  static Future<bool> loadDarkMode() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_themeKey) ?? true;
  }

  static Future<void> saveDarkMode(bool isDark) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_themeKey, isDark);
  }

  static String _historyKey(String productId, String variantLabel, bool isUsed) {
    final kind = isUsed ? 'used' : 'new';
    return 'hist_${productId}_${variantLabel}_$kind';
  }

  static Future<List<PricePoint>> loadHistory(
    String productId,
    String variantLabel,
    bool isUsed,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_historyKey(productId, variantLabel, isUsed));
    if (raw == null || raw.isEmpty) return [];
    try {
      final list = (jsonDecode(raw) as List<dynamic>)
          .map((e) => PricePoint.fromJson(e as Map<String, dynamic>))
          .toList();
      final cutoff = DateTime.now()
          .subtract(const Duration(days: 30))
          .millisecondsSinceEpoch;
      return list.where((p) => p.timestampMs >= cutoff).toList();
    } catch (_) {
      return [];
    }
  }

  static Future<List<PricePoint>> recordPrice({
    required String productId,
    required String variantLabel,
    required bool isUsed,
    required int priceTl,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    final existing = await loadHistory(productId, variantLabel, isUsed);
    final now = DateTime.now().millisecondsSinceEpoch;

    if (existing.isNotEmpty) {
      final last = existing.last;
      if ((now - last.timestampMs) < 30 * 60 * 1000 &&
          last.priceTl == priceTl) {
        return existing;
      }
    }

    final updated = [...existing, PricePoint(timestampMs: now, priceTl: priceTl)];
    final trimmed =
        updated.length > 60 ? updated.sublist(updated.length - 60) : updated;

    await prefs.setString(
      _historyKey(productId, variantLabel, isUsed),
      jsonEncode(trimmed.map((e) => e.toJson()).toList()),
    );
    return trimmed;
  }
}
