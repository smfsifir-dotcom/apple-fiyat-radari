import 'dart:convert';
import 'ai_filter.dart';

class DomExtractionOutput {
  final bool needsVerification;
  final List<RawListing> listings;

  const DomExtractionOutput({
    required this.needsVerification,
    required this.listings,
  });
}

class LiveScannerScripts {
  static const String akakceExtractJs = r'''
(function() {
  try {
    var bodyText = (document.body ? document.body.innerText : '').toLowerCase();
    var titleText = (document.title || '').toLowerCase();
    if (
      titleText.indexOf('just a moment') !== -1 ||
      titleText.indexOf('attention required') !== -1 ||
      bodyText.indexOf('verify you are human') !== -1 ||
      bodyText.indexOf('ben robot') !== -1 ||
      document.querySelector('iframe[src*="turnstile"]') ||
      document.querySelector('#challenge-running')
    ) {
      return JSON.stringify({ blocked: true, items: [] });
    }

    function parsePrice(str) {
      if (!str) return 0;
      var m = str.match(/(\d{1,3}(?:\.\d{3})+|\d{4,6})(?:,\d{1,2})?\s*(?:TL|₺)/i);
      if (!m) m = str.match(/(\d{1,3}(?:\.\d{3})+)/);
      if (!m) return 0;
      return parseInt(m[1].replace(/\./g, ''), 10) || 0;
    }

    var results = [];
    var seen = {};
    var nodes = document.querySelectorAll('ul#APL li, ul.pl_v9 li, li.w, article, a[href*=".html"]');

    for (var i = 0; i < nodes.length && results.length < 40; i++) {
      var el = nodes[i];
      var linkEl = el.tagName === 'A' ? el : el.querySelector('a[href]');
      if (!linkEl) continue;
      var href = linkEl.getAttribute('href') || '';
      if (!href || href.indexOf('javascript:') === 0) continue;
      if (href.indexOf('http') !== 0) {
        href = 'https://www.akakce.com' + (href.charAt(0) === '/' ? href : '/' + href);
      }
      if (seen[href]) continue;

      var nameEl = el.querySelector('h3, .pn_v8, span.pn_v8, .p_n') || linkEl;
      var title = (nameEl.innerText || linkEl.getAttribute('title') || '').trim();
      var priceEl = el.querySelector('.pt_v9, .pt_v8, span.pt_v9, [class*="price"]');
      var priceText = priceEl ? priceEl.innerText : (el.innerText || '');
      var price = parsePrice(priceText);

      if (title.length >= 6 && price >= 2500) {
        seen[href] = true;
        results.push({
          title: title.replace(/\s+/g, ' ').slice(0, 140),
          price: price,
          url: href,
          source: 'Akakce',
          extra: 'Sifir Magaza'
        });
      }
    }
    return JSON.stringify({ blocked: false, items: results });
  } catch (e) {
    return JSON.stringify({ blocked: false, items: [] });
  }
})();
''';

  static const String sahibindenExtractJs = r'''
(function() {
  try {
    var bodyText = (document.body ? document.body.innerText : '').toLowerCase();
    var titleText = (document.title || '').toLowerCase();
    if (
      titleText.indexOf('just a moment') !== -1 ||
      titleText.indexOf('olağan dışı') !== -1 ||
      bodyText.indexOf('olağan dışı erişim') !== -1 ||
      bodyText.indexOf('verify you are human') !== -1 ||
      bodyText.indexOf('ben robot değilim') !== -1 ||
      bodyText.indexOf('insan olduğunuzu doğrulayın') !== -1 ||
      document.querySelector('iframe[src*="turnstile"]') ||
      document.querySelector('#challenge-running')
    ) {
      return JSON.stringify({ blocked: true, items: [] });
    }

    function parsePrice(str) {
      if (!str) return 0;
      var m = str.match(/(\d{1,3}(?:\.\d{3})+|\d{4,6})\s*(?:TL|₺)/i);
      if (!m) m = str.match(/(\d{1,3}(?:\.\d{3})+)/);
      if (!m) return 0;
      return parseInt(m[1].replace(/\./g, ''), 10) || 0;
    }

    var results = [];
    var seen = {};
    var rows = document.querySelectorAll('tr.searchResultsItem, li.search-result-item, div[data-id], a[href*="/ilan/"]');

    for (var i = 0; i < rows.length && results.length < 45; i++) {
      var el = rows[i];
      var linkEl = el.tagName === 'A' ? el : el.querySelector('a.classifiedTitle, a[href*="/ilan/"]');
      if (!linkEl) continue;
      var href = linkEl.getAttribute('href') || '';
      if (href.indexOf('/ilan/') === -1) continue;
      if (href.indexOf('http') !== 0) {
        href = 'https://www.sahibinden.com' + (href.charAt(0) === '/' ? href : '/' + href);
      }
      if (seen[href]) continue;

      var title = (linkEl.innerText || linkEl.getAttribute('title') || '').trim();
      var container = el.tagName === 'A' ? (el.closest('tr, li, article, div') || el) : el;
      var priceEl = container.querySelector('.searchResultsPriceValue, [class*="price"], [class*="Price"]');
      var priceText = priceEl ? priceEl.innerText : (container.innerText || '');
      var price = parsePrice(priceText);

      var locEl = container.querySelector('.searchResultsLocationValue, [class*="location"], [class*="city"]');
      var loc = locEl ? locEl.innerText.replace(/\s+/g, ' ').trim() : 'Sahibinden';

      if (title.length >= 6 && price >= 2500) {
        seen[href] = true;
        results.push({
          title: title.replace(/\s+/g, ' ').slice(0, 140),
          price: price,
          url: href,
          source: 'Sahibinden',
          extra: loc.slice(0, 40)
        });
      }
    }
    return JSON.stringify({ blocked: false, items: results });
  } catch (e) {
    return JSON.stringify({ blocked: false, items: [] });
  }
})();
''';

  static DomExtractionOutput parseJsResult(Object rawResult) {
    try {
      String text = rawResult.toString();
      if (text.startsWith('"') && text.endsWith('"')) {
        text = jsonDecode(text) as String;
      }
      final map = jsonDecode(text) as Map<String, dynamic>;
      final blocked = map['blocked'] == true;
      final rawItems = (map['items'] as List<dynamic>? ?? []);
      final list = <RawListing>[];
      for (final entry in rawItems) {
        final m = entry as Map<String, dynamic>;
        final title = (m['title'] ?? '').toString().trim();
        final price = (m['price'] as num?)?.toInt() ?? 0;
        final url = (m['url'] ?? '').toString().trim();
        final source = (m['source'] ?? '').toString().trim();
        final extra = (m['extra'] ?? '').toString().trim();
        if (title.isNotEmpty && price > 0 && url.startsWith('https://')) {
          list.add(RawListing(
            title: title,
            priceTl: price,
            url: url,
            source: source,
            sellerOrCity: extra,
          ));
        }
      }
      return DomExtractionOutput(needsVerification: blocked, listings: list);
    } catch (_) {
      return const DomExtractionOutput(needsVerification: false, listings: []);
    }
  }
}
