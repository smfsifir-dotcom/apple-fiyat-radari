import 'dart:async';
import 'dart:ui' show FontFeature;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'models/apple_catalog.dart';
import 'services/ai_filter.dart';
import 'services/history_store.dart';
import 'services/live_scanner.dart';
import 'widgets/sparkline.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const AppleRadarApp());
}

enum ScanStage { idle, scanning, found, empty, needsVerify }

class CardScanState {
  final ScanStage stage;
  final AiFilteredResult? result;

  const CardScanState({
    this.stage = ScanStage.idle,
    this.result,
  });
}

class AppleRadarApp extends StatefulWidget {
  const AppleRadarApp({super.key});

  @override
  State<AppleRadarApp> createState() => _AppleRadarAppState();
}

class _AppleRadarAppState extends State<AppleRadarApp> {
  bool _isDark = true;

  @override
  void initState() {
    super.initState();
    HistoryStore.loadDarkMode().then((v) {
      if (mounted) setState(() => _isDark = v);
    });
  }

  void _toggleTheme() {
    setState(() => _isDark = !_isDark);
    HistoryStore.saveDarkMode(_isDark);
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Apple Fiyat Radarı',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: _isDark ? Brightness.dark : Brightness.light,
        scaffoldBackgroundColor:
            _isDark ? const Color(0xFF111318) : const Color(0xFFF5F5F7),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: RadarHomePage(
        isDark: _isDark,
        onToggleTheme: _toggleTheme,
      ),
    );
  }
}

class RadarHomePage extends StatefulWidget {
  final bool isDark;
  final VoidCallback onToggleTheme;

  const RadarHomePage({
    super.key,
    required this.isDark,
    required this.onToggleTheme,
  });

  @override
  State<RadarHomePage> createState() => _RadarHomePageState();
}

class _RadarHomePageState extends State<RadarHomePage> {
  AppleCategory _category = AppleCategory.all;
  AppleProduct _product = kAppleCatalog.first;
  int _variantIdx = 0;
  bool _trOnly = true;

  // null = closed, false = verifying Akakce, true = verifying Sahibinden
  bool? _verifyingIsUsed;

  CardScanState _newState = const CardScanState();
  CardScanState _usedState = const CardScanState();

  List<PricePoint> _newHistory = [];
  List<PricePoint> _usedHistory = [];

  late final WebViewController _newWebCtrl;
  late final WebViewController _usedWebCtrl;

  int _scanToken = 0;
  Timer? _newTimeout;
  Timer? _usedTimeout;

  static const String _mobileUa =
      'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36';

  SpecVariant get _variant =>
      _product.variants[_variantIdx.clamp(0, _product.variants.length - 1)];

  List<AppleProduct> get _filteredProducts => _category == AppleCategory.all
      ? kAppleCatalog
      : kAppleCatalog.where((p) => p.category == _category).toList();

  @override
  void initState() {
    super.initState();
    _initWebEngines();
    _loadHistories();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _startLiveScan();
    });
  }

  @override
  void dispose() {
    _newTimeout?.cancel();
    _usedTimeout?.cancel();
    super.dispose();
  }

  void _initWebEngines() {
    _newWebCtrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(_mobileUa)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (url) => _handleNewPageFinished(url, _scanToken),
          onWebResourceError: (_) {},
        ),
      );

    _usedWebCtrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent(_mobileUa)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (url) => _handleUsedPageFinished(url, _scanToken),
          onWebResourceError: (_) {},
        ),
      );
  }

  Future<void> _loadHistories() async {
    final nh =
        await HistoryStore.loadHistory(_product.id, _variant.label, false);
    final uh =
        await HistoryStore.loadHistory(_product.id, _variant.label, true);
    if (!mounted) return;
    setState(() {
      _newHistory = nh;
      _usedHistory = uh;
    });
  }

  void _startLiveScan() {
    _scanToken++;
    final token = _scanToken;
    _newTimeout?.cancel();
    _usedTimeout?.cancel();

    setState(() {
      _newState = const CardScanState(stage: ScanStage.scanning);
      _usedState = const CardScanState(stage: ScanStage.scanning);
    });

    final newUrl = _product.akakceUrl(_variant);
    final usedUrl = _product.sahibindenUrl(_variant, trOnly: _trOnly);

    _newWebCtrl.loadRequest(Uri.parse(newUrl));
    _usedWebCtrl.loadRequest(Uri.parse(usedUrl));

    _newTimeout = Timer(const Duration(seconds: 16), () {
      if (!mounted || token != _scanToken) return;
      if (_newState.stage == ScanStage.scanning) {
        setState(() => _newState = const CardScanState(stage: ScanStage.empty));
      }
    });

    _usedTimeout = Timer(const Duration(seconds: 16), () {
      if (!mounted || token != _scanToken) return;
      if (_usedState.stage == ScanStage.scanning) {
        setState(
            () => _usedState = const CardScanState(stage: ScanStage.empty));
      }
    });
  }

  Future<void> _handleNewPageFinished(String url, int token) async {
    if (!mounted || token != _scanToken) return;
    await Future.delayed(const Duration(milliseconds: 1100));
    if (!mounted || token != _scanToken) return;

    try {
      final raw = await _newWebCtrl
          .runJavaScriptReturningResult(LiveScannerScripts.akakceExtractJs);
      if (!mounted || token != _scanToken) return;

      final parsed = LiveScannerScripts.parseJsResult(raw);
      if (parsed.needsVerification) {
        _newTimeout?.cancel();
        setState(() =>
            _newState = const CardScanState(stage: ScanStage.needsVerify));
        return;
      }

      if (parsed.listings.isEmpty) {
        return;
      }

      final filtered = AiListingFilter.evaluate(
        listings: parsed.listings,
        product: _product,
        variant: _variant,
        isUsed: false,
        trOnly: _trOnly,
      );

      _newTimeout?.cancel();
      if (filtered.bestListing != null) {
        final hist = await HistoryStore.recordPrice(
          productId: _product.id,
          variantLabel: _variant.label,
          isUsed: false,
          priceTl: filtered.bestListing!.priceTl,
        );
        if (!mounted || token != _scanToken) return;
        setState(() {
          _newHistory = hist;
          _newState = CardScanState(stage: ScanStage.found, result: filtered);
        });
      } else {
        setState(() {
          _newState = CardScanState(stage: ScanStage.empty, result: filtered);
        });
      }
    } catch (_) {}
  }

  Future<void> _handleUsedPageFinished(String url, int token) async {
    if (!mounted || token != _scanToken) return;
    await Future.delayed(const Duration(milliseconds: 1300));
    if (!mounted || token != _scanToken) return;

    try {
      final raw = await _usedWebCtrl
          .runJavaScriptReturningResult(LiveScannerScripts.sahibindenExtractJs);
      if (!mounted || token != _scanToken) return;

      final parsed = LiveScannerScripts.parseJsResult(raw);
      if (parsed.needsVerification) {
        _usedTimeout?.cancel();
        setState(() =>
            _usedState = const CardScanState(stage: ScanStage.needsVerify));
        return;
      }

      if (parsed.listings.isEmpty) {
        return;
      }

      final filtered = AiListingFilter.evaluate(
        listings: parsed.listings,
        product: _product,
        variant: _variant,
        isUsed: true,
        trOnly: _trOnly,
      );

      _usedTimeout?.cancel();
      if (filtered.bestListing != null) {
        final hist = await HistoryStore.recordPrice(
          productId: _product.id,
          variantLabel: _variant.label,
          isUsed: true,
          priceTl: filtered.bestListing!.priceTl,
        );
        if (!mounted || token != _scanToken) return;
        setState(() {
          _usedHistory = hist;
          _usedState = CardScanState(stage: ScanStage.found, result: filtered);
        });
      } else {
        setState(() {
          _usedState = CardScanState(stage: ScanStage.empty, result: filtered);
        });
      }
    } catch (_) {}
  }

  void _selectCategory(AppleCategory cat) {
    setState(() {
      _category = cat;
      final list = _filteredProducts;
      if (!list.any((p) => p.id == _product.id) && list.isNotEmpty) {
        _product = list.first;
        _variantIdx = 0;
      }
    });
    _loadHistories();
    _startLiveScan();
  }

  void _selectProduct(AppleProduct prod) {
    setState(() {
      _product = prod;
      _variantIdx = 0;
    });
    _loadHistories();
    _startLiveScan();
  }

  void _selectVariant(int idx) {
    setState(() => _variantIdx = idx);
    _loadHistories();
    _startLiveScan();
  }

  Future<void> _openExternal(String url) async {
    final uri = Uri.tryParse(url);
    if (uri == null) return;
    const allowed = [
      'akakce.com',
      'cimri.com',
      'pt.com.tr',
      'apple.com',
      'sahibinden.com',
      'letgo.com',
      'dolap.com',
      'easycep.com',
      'getmobil.com',
    ];
    final hostOk = allowed.any(
      (d) => uri.host == d || uri.host.endsWith('.$d'),
    );
    if (!hostOk) return;
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  void _openToolsSheet() {
    final isDark = widget.isDark;
    final bg = isDark ? const Color(0xFF181B22) : Colors.white;
    final border = isDark ? const Color(0xFF282E3A) : const Color(0xFFE5E7EB);

    final questions = _product.category == AppleCategory.iphone
        ? 'Merhaba, ${_product.name} (${_variant.label}) ilanınızla ilgileniyorum. Cihaz TR kayıtlı ve faturalı mı? Pil sağlığı % kaç? Face ID, True Tone, ekran veya arka camda değişen/tamir var mı? iCloud çıkışı yapılarak elden/Param Güvende ile teslim alabilir miyim?'
        : 'Merhaba, ${_product.name} (${_variant.label}) ilanınızla ilgileniyorum. Kutu, fatura ve seri numarası eşleşiyor mu? Pil döngüsü/sağlığı nedir? iCloud ve kurumsal MDM kilidi temiz mi?';

    showModalBottomSheet(
      context: context,
      backgroundColor: bg,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
      ),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Diğer Platformlar & Yardımcı Araçlar',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _toolChip('Cimri ↗',
                      () => _openExternal(_product.cimriUrl(_variant)), border),
                  _toolChip('Pozitif Teknoloji ↗',
                      () => _openExternal(_product.ptUrl(_variant)), border),
                  _toolChip(
                      'Apple TR ↗',
                      () => _openExternal(_product.appleTrUrl(_variant)),
                      border),
                  _toolChip(
                      'Letgo ↗',
                      () => _openExternal(
                          _product.letgoUrl(_variant, trOnly: _trOnly)),
                      border),
                  _toolChip(
                      'Dolap ↗',
                      () => _openExternal(
                          _product.dolapUrl(_variant, trOnly: _trOnly)),
                      border),
                  _toolChip(
                      'EasyCep ↗',
                      () => _openExternal(_product.easyCepUrl(_variant)),
                      border),
                  _toolChip(
                      'Getmobil ↗',
                      () => _openExternal(_product.getmobilUrl(_variant)),
                      border),
                ],
              ),
              const SizedBox(height: 14),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Clipboard.setData(ClipboardData(text: questions));
                        Navigator.pop(ctx);
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content:
                                Text('Satıcıya sorulacak sorular kopyalandı.'),
                            duration: Duration(seconds: 2),
                          ),
                        );
                      },
                      icon: const Icon(Icons.copy_rounded, size: 16),
                      label: const Text('Satıcıya Sor',
                          style: TextStyle(fontSize: 12)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () {
                        Navigator.pop(ctx);
                        _openExternal('https://checkcoverage.apple.com/tr/tr/');
                      },
                      icon: const Icon(Icons.verified_user_outlined, size: 16),
                      label: const Text('Garanti Sorgula',
                          style: TextStyle(fontSize: 12)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _toolChip(String label, VoidCallback onTap, Color border) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(10),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 7),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: border),
        ),
        child: Text(label,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500)),
      ),
    );
  }

  static String _formatTl(int amount) {
    final s = amount.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      final rev = s.length - i;
      buf.write(s[i]);
      if (rev > 1 && rev % 3 == 1) buf.write('.');
    }
    return '${buf.toString()} TL';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = widget.isDark;
    final bg = isDark ? const Color(0xFF111318) : const Color(0xFFF5F5F7);
    final cardBg = isDark ? const Color(0xFF181B22) : Colors.white;
    final border = isDark ? const Color(0xFF262B36) : const Color(0xFFE5E7EB);
    final textMain = isDark ? const Color(0xFFE5E7EB) : const Color(0xFF1D1D1F);
    final textMuted =
        isDark ? const Color(0xFF8B93A3) : const Color(0xFF6E6E73);
    final accent = isDark ? const Color(0xFF60A5FA) : const Color(0xFF0071E3);

    return Scaffold(
      backgroundColor: bg,
      body: SafeArea(
        child: Stack(
          children: [
            // Single-instance hidden on-device engines (unmounted when shown in verification overlay)
            if (_verifyingIsUsed != false)
              Positioned(
                left: -10,
                top: -10,
                width: 1,
                height: 1,
                child: Opacity(
                  opacity: 0.01,
                  child: WebViewWidget(controller: _newWebCtrl),
                ),
              ),
            if (_verifyingIsUsed != true)
              Positioned(
                left: -10,
                top: -10,
                width: 1,
                height: 1,
                child: Opacity(
                  opacity: 0.01,
                  child: WebViewWidget(controller: _usedWebCtrl),
                ),
              ),

            // Main Ultra-Minimal Apple Studio UI
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Apple Fiyat Radarı',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w700,
                                color: textMain,
                                letterSpacing: -0.3,
                              ),
                            ),
                            Row(
                              children: [
                                Container(
                                  width: 7,
                                  height: 7,
                                  decoration: const BoxDecoration(
                                    color: Color(0xFF34D399),
                                    shape: BoxShape.circle,
                                  ),
                                ),
                                const SizedBox(width: 5),
                                Text(
                                  'Cihaz içi canlı motor aktif',
                                  style:
                                      TextStyle(fontSize: 11, color: textMuted),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      IconButton(
                        onPressed: widget.onToggleTheme,
                        icon: Icon(
                          isDark
                              ? Icons.wb_sunny_outlined
                              : Icons.nightlight_outlined,
                          size: 19,
                          color: textMain,
                        ),
                        tooltip: 'Tema Değiştir',
                      ),
                      const SizedBox(width: 4),
                      FilledButton.icon(
                        onPressed: _startLiveScan,
                        style: FilledButton.styleFrom(
                          backgroundColor: accent,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(
                              horizontal: 12, vertical: 8),
                          minimumSize: const Size(0, 36),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                        icon: const Icon(Icons.refresh_rounded, size: 16),
                        label: const Text('Tara',
                            style: TextStyle(
                                fontSize: 12, fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),

                  // Category Chips
                  SizedBox(
                    height: 32,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: AppleCategory.values.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 6),
                      itemBuilder: (_, idx) {
                        final cat = AppleCategory.values[idx];
                        final active = cat == _category;
                        return InkWell(
                          onTap: () => _selectCategory(cat),
                          borderRadius: BorderRadius.circular(999),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: active ? accent : cardBg,
                              borderRadius: BorderRadius.circular(999),
                              border: Border.all(
                                color: active ? accent : border,
                              ),
                            ),
                            child: Text(
                              cat.label,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: active ? Colors.white : textMuted,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Model Selector + TR Toggle
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          height: 40,
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          decoration: BoxDecoration(
                            color: cardBg,
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: border),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: _product.id,
                              isExpanded: true,
                              dropdownColor: cardBg,
                              style: TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                                color: textMain,
                              ),
                              items: _filteredProducts
                                  .map(
                                    (p) => DropdownMenuItem(
                                      value: p.id,
                                      child: Text(
                                        p.name,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  )
                                  .toList(),
                              onChanged: (id) {
                                if (id == null) return;
                                final prod = _filteredProducts
                                    .firstWhere((p) => p.id == id);
                                _selectProduct(prod);
                              },
                            ),
                          ),
                        ),
                      ),
                      if (_product.supportsTrFilter) ...[
                        const SizedBox(width: 8),
                        InkWell(
                          onTap: () {
                            setState(() => _trOnly = !_trOnly);
                            _startLiveScan();
                          },
                          borderRadius: BorderRadius.circular(10),
                          child: Container(
                            height: 40,
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: _trOnly
                                  ? const Color.fromRGBO(52, 211, 153, 0.14)
                                  : cardBg,
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                color:
                                    _trOnly ? const Color(0xFF34D399) : border,
                              ),
                            ),
                            child: Text(
                              _trOnly ? 'TR Cihaz' : 'Tümü',
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w600,
                                color: _trOnly
                                    ? const Color(0xFF34D399)
                                    : textMuted,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  const SizedBox(height: 8),

                  // Hardware-locked Spec Variants
                  SizedBox(
                    height: 30,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: _product.variants.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 6),
                      itemBuilder: (_, idx) {
                        final v = _product.variants[idx];
                        final active = idx == _variantIdx;
                        return InkWell(
                          onTap: () => _selectVariant(idx),
                          borderRadius: BorderRadius.circular(8),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10),
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: active
                                  ? Color.fromRGBO(
                                      isDark ? 96 : 0,
                                      isDark ? 165 : 113,
                                      isDark ? 250 : 227,
                                      0.16,
                                    )
                                  : cardBg,
                              borderRadius: BorderRadius.circular(8),
                              border:
                                  Border.all(color: active ? accent : border),
                            ),
                            child: Text(
                              v.label,
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w600,
                                color: active ? accent : textMuted,
                              ),
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 12),

                  // STRICTLY SIDE-BY-SIDE CARDS
                  Expanded(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Expanded(
                          child: _buildPriceCard(
                            isUsed: false,
                            title: 'En Ucuz Sıfır',
                            sourceLabel: 'Akakçe Canlı',
                            state: _newState,
                            history: _newHistory,
                            fallbackUrl: _product.akakceUrl(_variant),
                            cardBg: cardBg,
                            border: border,
                            textMain: textMain,
                            textMuted: textMuted,
                            accent: accent,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _buildPriceCard(
                            isUsed: true,
                            title: 'En Ucuz 2. El',
                            sourceLabel: 'Sahibinden AI',
                            state: _usedState,
                            history: _usedHistory,
                            fallbackUrl: _product.sahibindenUrl(_variant,
                                trOnly: _trOnly),
                            cardBg: cardBg,
                            border: border,
                            textMain: textMain,
                            textMuted: textMuted,
                            accent: const Color(0xFF34D399),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),

                  // Clean Bottom Bar
                  InkWell(
                    onTap: _openToolsSheet,
                    borderRadius: BorderRadius.circular(10),
                    child: Container(
                      height: 42,
                      padding: const EdgeInsets.symmetric(horizontal: 14),
                      decoration: BoxDecoration(
                        color: cardBg,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: border),
                      ),
                      child: Row(
                        children: [
                          Icon(Icons.tune_rounded, size: 16, color: textMuted),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              'Diğer Platformlar, Satıcı Soruları & Garanti',
                              overflow: TextOverflow.ellipsis,
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.w500,
                                color: textMain,
                              ),
                            ),
                          ),
                          Icon(Icons.keyboard_arrow_up_rounded,
                              size: 18, color: textMuted),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Single-instance Human Verification Overlay
            if (_verifyingIsUsed != null)
              Positioned.fill(
                child: Container(
                  color: bg,
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 10),
                        decoration: BoxDecoration(
                          color: cardBg,
                          border: Border(bottom: BorderSide(color: border)),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                _verifyingIsUsed!
                                    ? 'Sahibinden Doğrulama — Kutuyu işaretleyip Tamam\'a basın'
                                    : 'Akakçe Doğrulama — Kutuyu işaretleyip Tamam\'a basın',
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.w600,
                                  color: textMain,
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            FilledButton(
                              onPressed: () {
                                setState(() => _verifyingIsUsed = null);
                                _startLiveScan();
                              },
                              child: const Text('Tamam'),
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: WebViewWidget(
                          controller:
                              _verifyingIsUsed! ? _usedWebCtrl : _newWebCtrl,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildPriceCard({
    required bool isUsed,
    required String title,
    required String sourceLabel,
    required CardScanState state,
    required List<PricePoint> history,
    required String fallbackUrl,
    required Color cardBg,
    required Color border,
    required Color textMain,
    required Color textMuted,
    required Color accent,
  }) {
    final winner = state.result?.bestListing;
    final targetUrl = winner != null ? winner.url : fallbackUrl;
    final eliminated = state.result?.eliminatedCount ?? 0;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: textMain,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            sourceLabel,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 11, color: textMuted),
          ),
          const SizedBox(height: 12),
          if (state.stage == ScanStage.scanning) ...[
            Row(
              children: [
                SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: accent,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Taranıyor...',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      color: textMuted,
                    ),
                  ),
                ),
              ],
            ),
          ] else if (state.stage == ScanStage.found && winner != null) ...[
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: Text(
                _formatTl(winner.priceTl),
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w800,
                  color: textMain,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              winner.title,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 11, color: textMuted, height: 1.3),
            ),
            if (eliminated > 0) ...[
              const SizedBox(height: 6),
              Text(
                'AI: $eliminated sahte/uyumsuz ilan elendi',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color: accent,
                ),
              ),
            ],
          ] else if (state.stage == ScanStage.needsVerify) ...[
            Text(
              'Güvenlik Kontrolü',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: textMain,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Site tek tıkla insan doğrulaması istiyor.',
              style: TextStyle(fontSize: 11, color: textMuted, height: 1.3),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton(
                onPressed: () => setState(() => _verifyingIsUsed = isUsed),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 6),
                  side: BorderSide(color: accent),
                ),
                child: Text(
                  'Doğrulamayı Geç',
                  style: TextStyle(fontSize: 11, color: accent),
                ),
              ),
            ),
          ] else ...[
            Text(
              'Doğrudan Canlı Liste',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: textMain,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Filtreli en ucuz sonuçları canlı açmak için dokunun.',
              style: TextStyle(fontSize: 11, color: textMuted, height: 1.3),
            ),
          ],
          const Spacer(),
          PriceSparkline(points: history, isDark: widget.isDark),
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            height: 40,
            child: FilledButton(
              onPressed: () => _openExternal(targetUrl),
              style: FilledButton.styleFrom(
                backgroundColor: accent,
                foregroundColor:
                    isUsed ? const Color(0xFF0A1410) : Colors.white,
                padding: const EdgeInsets.symmetric(horizontal: 8),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: Text(
                winner != null ? 'Tek İlana Git ↗' : 'Siteye Git ↗',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
