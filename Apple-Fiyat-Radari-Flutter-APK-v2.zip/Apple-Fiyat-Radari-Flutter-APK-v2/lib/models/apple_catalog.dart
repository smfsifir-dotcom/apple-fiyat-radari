enum AppleCategory {
  all('Tümü'),
  mac('Mac'),
  iphone('iPhone'),
  ipad('iPad'),
  watch('Watch'),
  airpods('AirPods');

  final String label;
  const AppleCategory(this.label);
}

class SpecVariant {
  final String label;
  final String queryToken;
  final double priceFactor;
  final List<String> requiredTokens;

  const SpecVariant({
    required this.label,
    required this.queryToken,
    required this.priceFactor,
    required this.requiredTokens,
  });
}

class AppleProduct {
  final String id;
  final String name;
  final AppleCategory category;
  final String akakceBaseQuery;
  final String sahibindenBaseQuery;
  final String sahibindenCategory;
  final int refNewFloorTl;
  final int refUsedFloorTl;
  final List<String> mustContainTokens;
  final List<String> forbidModelTokens;
  final List<SpecVariant> variants;
  final bool supportsTrFilter;

  const AppleProduct({
    required this.id,
    required this.name,
    required this.category,
    required this.akakceBaseQuery,
    required this.sahibindenBaseQuery,
    required this.sahibindenCategory,
    required this.refNewFloorTl,
    required this.refUsedFloorTl,
    required this.mustContainTokens,
    required this.forbidModelTokens,
    required this.variants,
    this.supportsTrFilter = false,
  });

  int minNewSanity(SpecVariant v) =>
      ((refNewFloorTl * v.priceFactor) * 0.65).round();

  int maxNewSanity(SpecVariant v) =>
      ((refNewFloorTl * v.priceFactor) * 1.95).round();

  int minUsedSanity(SpecVariant v) =>
      ((refUsedFloorTl * v.priceFactor) * 0.58).round();

  int maxUsedSanity(SpecVariant v) =>
      ((refUsedFloorTl * v.priceFactor) * 1.65).round();

  String buildNewQuery(SpecVariant v) {
    final parts = [akakceBaseQuery, v.queryToken]
        .where((e) => e.trim().isNotEmpty)
        .join(' ');
    return parts.trim();
  }

  String buildUsedQuery(SpecVariant v, {bool trOnly = true}) {
    final parts = [
      sahibindenBaseQuery,
      v.queryToken,
      if (supportsTrFilter && trOnly) 'TR',
    ].where((e) => e.trim().isNotEmpty).join(' ');
    return parts.trim();
  }

  String akakceUrl(SpecVariant v) {
    final q = Uri.encodeQueryComponent(buildNewQuery(v));
    return 'https://www.akakce.com/arama/?q=$q&s=2';
  }

  String cimriUrl(SpecVariant v) {
    final q = Uri.encodeQueryComponent(buildNewQuery(v));
    return 'https://www.cimri.com/arama?q=$q&sort=price_asc';
  }

  String ptUrl(SpecVariant v) {
    final q = Uri.encodeQueryComponent(buildNewQuery(v));
    return 'https://www.pt.com.tr/arama?q=$q';
  }

  String appleTrUrl(SpecVariant v) {
    final q = Uri.encodeComponent(name);
    return 'https://www.apple.com/tr/search/$q';
  }

  String sahibindenUrl(SpecVariant v, {bool trOnly = true}) {
    final q = Uri.encodeQueryComponent(buildUsedQuery(v, trOnly: trOnly));
    final minP = minUsedSanity(v);
    final maxP = maxUsedSanity(v);
    return 'https://www.sahibinden.com/$sahibindenCategory'
        '?query_text=$q&price_min=$minP&price_max=$maxP&sorting=price_asc';
  }

  String letgoUrl(SpecVariant v, {bool trOnly = true}) {
    final q = Uri.encodeQueryComponent(buildUsedQuery(v, trOnly: trOnly));
    final minP = minUsedSanity(v);
    final maxP = maxUsedSanity(v);
    return 'https://www.letgo.com/arama?q=$q&price_min=$minP&price_max=$maxP';
  }

  String dolapUrl(SpecVariant v, {bool trOnly = true}) {
    final q = Uri.encodeQueryComponent(buildUsedQuery(v, trOnly: trOnly));
    final minP = minUsedSanity(v);
    final maxP = maxUsedSanity(v);
    return 'https://dolap.com/ara?q=$q&minPrice=$minP&maxPrice=$maxP';
  }

  String easyCepUrl(SpecVariant v) {
    final q = Uri.encodeQueryComponent(name);
    return 'https://easycep.com/arama?q=$q';
  }

  String getmobilUrl(SpecVariant v) {
    final q = Uri.encodeQueryComponent(name);
    return 'https://getmobil.com/arama/?q=$q';
  }
}

const List<AppleProduct> kAppleCatalog = [
  AppleProduct(
    id: 'mac-mini-m4',
    name: 'Mac mini M4',
    category: AppleCategory.mac,
    akakceBaseQuery: 'Apple Mac mini M4',
    sahibindenBaseQuery: 'Mac mini M4',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-masaustu',
    refNewFloorTl: 27000,
    refUsedFloorTl: 22000,
    mustContainTokens: ['mini', 'm4'],
    forbidModelTokens: ['m4 pro', 'm2', 'm1', 'studio'],
    variants: [
      SpecVariant(label: '16 GB / 256 GB', queryToken: '16GB 256GB', priceFactor: 1.0, requiredTokens: ['16', '256']),
      SpecVariant(label: '16 GB / 512 GB', queryToken: '16GB 512GB', priceFactor: 1.28, requiredTokens: ['16', '512']),
      SpecVariant(label: '24 GB / 512 GB', queryToken: '24GB 512GB', priceFactor: 1.55, requiredTokens: ['24', '512']),
    ],
  ),
  AppleProduct(
    id: 'mac-mini-m4-pro',
    name: 'Mac mini M4 Pro',
    category: AppleCategory.mac,
    akakceBaseQuery: 'Apple Mac mini M4 Pro',
    sahibindenBaseQuery: 'Mac mini M4 Pro',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-masaustu',
    refNewFloorTl: 62000,
    refUsedFloorTl: 52000,
    mustContainTokens: ['mini', 'm4', 'pro'],
    forbidModelTokens: ['m2', 'm1', 'studio'],
    variants: [
      SpecVariant(label: '24 GB / 512 GB', queryToken: '24GB 512GB', priceFactor: 1.0, requiredTokens: ['24', '512']),
      SpecVariant(label: '48 GB / 1 TB', queryToken: '48GB 1TB', priceFactor: 1.38, requiredTokens: ['48', '1tb']),
    ],
  ),
  AppleProduct(
    id: 'mac-mini-m2',
    name: 'Mac mini M2',
    category: AppleCategory.mac,
    akakceBaseQuery: 'Apple Mac mini M2',
    sahibindenBaseQuery: 'Mac mini M2',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-masaustu',
    refNewFloorTl: 23000,
    refUsedFloorTl: 16500,
    mustContainTokens: ['mini', 'm2'],
    forbidModelTokens: ['m4', 'm1', 'm2 pro', 'studio'],
    variants: [
      SpecVariant(label: '8 GB / 256 GB', queryToken: '8GB 256GB', priceFactor: 1.0, requiredTokens: ['8', '256']),
      SpecVariant(label: '16 GB / 256 GB', queryToken: '16GB 256GB', priceFactor: 1.25, requiredTokens: ['16', '256']),
      SpecVariant(label: '16 GB / 512 GB', queryToken: '16GB 512GB', priceFactor: 1.42, requiredTokens: ['16', '512']),
    ],
  ),
  AppleProduct(
    id: 'mba-m4-13',
    name: 'MacBook Air 13" M4',
    category: AppleCategory.mac,
    akakceBaseQuery: 'MacBook Air M4 13',
    sahibindenBaseQuery: 'MacBook Air M4 13',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-dizustu-bilgisayar',
    refNewFloorTl: 46000,
    refUsedFloorTl: 38000,
    mustContainTokens: ['air', 'm4'],
    forbidModelTokens: ['pro', 'm3', 'm2', 'm1', '15'],
    variants: [
      SpecVariant(label: '16 GB / 256 GB', queryToken: '16GB 256GB', priceFactor: 1.0, requiredTokens: ['16', '256']),
      SpecVariant(label: '16 GB / 512 GB', queryToken: '16GB 512GB', priceFactor: 1.18, requiredTokens: ['16', '512']),
      SpecVariant(label: '24 GB / 512 GB', queryToken: '24GB 512GB', priceFactor: 1.35, requiredTokens: ['24', '512']),
    ],
  ),
  AppleProduct(
    id: 'mba-m3-13',
    name: 'MacBook Air 13" M3',
    category: AppleCategory.mac,
    akakceBaseQuery: 'MacBook Air M3 13',
    sahibindenBaseQuery: 'MacBook Air M3 13',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-dizustu-bilgisayar',
    refNewFloorTl: 41000,
    refUsedFloorTl: 32000,
    mustContainTokens: ['air', 'm3'],
    forbidModelTokens: ['pro', 'm4', 'm2', 'm1', '15'],
    variants: [
      SpecVariant(label: '16 GB / 256 GB', queryToken: '16GB 256GB', priceFactor: 1.0, requiredTokens: ['16', '256']),
      SpecVariant(label: '16 GB / 512 GB', queryToken: '16GB 512GB', priceFactor: 1.18, requiredTokens: ['16', '512']),
      SpecVariant(label: '8 GB / 256 GB', queryToken: '8GB 256GB', priceFactor: 0.88, requiredTokens: ['8', '256']),
    ],
  ),
  AppleProduct(
    id: 'mba-m2-13',
    name: 'MacBook Air 13" M2',
    category: AppleCategory.mac,
    akakceBaseQuery: 'MacBook Air M2 13',
    sahibindenBaseQuery: 'MacBook Air M2 13',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-dizustu-bilgisayar',
    refNewFloorTl: 34000,
    refUsedFloorTl: 25500,
    mustContainTokens: ['air', 'm2'],
    forbidModelTokens: ['pro', 'm4', 'm3', 'm1', '15'],
    variants: [
      SpecVariant(label: '16 GB / 256 GB', queryToken: '16GB 256GB', priceFactor: 1.08, requiredTokens: ['16', '256']),
      SpecVariant(label: '8 GB / 256 GB', queryToken: '8GB 256GB', priceFactor: 0.92, requiredTokens: ['8', '256']),
      SpecVariant(label: '16 GB / 512 GB', queryToken: '16GB 512GB', priceFactor: 1.24, requiredTokens: ['16', '512']),
    ],
  ),
  AppleProduct(
    id: 'mba-m1-13',
    name: 'MacBook Air 13" M1',
    category: AppleCategory.mac,
    akakceBaseQuery: 'MacBook Air M1',
    sahibindenBaseQuery: 'MacBook Air M1',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-dizustu-bilgisayar',
    refNewFloorTl: 27000,
    refUsedFloorTl: 18500,
    mustContainTokens: ['air', 'm1'],
    forbidModelTokens: ['pro', 'm4', 'm3', 'm2'],
    variants: [
      SpecVariant(label: '8 GB / 256 GB', queryToken: '8GB 256GB', priceFactor: 1.0, requiredTokens: ['8', '256']),
      SpecVariant(label: '16 GB / 256 GB', queryToken: '16GB 256GB', priceFactor: 1.2, requiredTokens: ['16', '256']),
      SpecVariant(label: '16 GB / 512 GB', queryToken: '16GB 512GB', priceFactor: 1.32, requiredTokens: ['16', '512']),
    ],
  ),
  AppleProduct(
    id: 'mbp-14-m4',
    name: 'MacBook Pro 14" M4',
    category: AppleCategory.mac,
    akakceBaseQuery: 'MacBook Pro 14 M4',
    sahibindenBaseQuery: 'MacBook Pro 14 M4',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-dizustu-bilgisayar',
    refNewFloorTl: 72000,
    refUsedFloorTl: 58000,
    mustContainTokens: ['pro', 'm4'],
    forbidModelTokens: ['air', 'm3', 'm2', 'm1', '16 inch', 'm4 max'],
    variants: [
      SpecVariant(label: '16 GB / 512 GB', queryToken: '16GB 512GB', priceFactor: 1.0, requiredTokens: ['16', '512']),
      SpecVariant(label: '16 GB / 1 TB', queryToken: '16GB 1TB', priceFactor: 1.15, requiredTokens: ['16', '1tb']),
      SpecVariant(label: '24 GB / 1 TB', queryToken: '24GB 1TB', priceFactor: 1.3, requiredTokens: ['24', '1tb']),
    ],
  ),
  AppleProduct(
    id: 'mbp-14-m4-pro',
    name: 'MacBook Pro 14" M4 Pro',
    category: AppleCategory.mac,
    akakceBaseQuery: 'MacBook Pro 14 M4 Pro',
    sahibindenBaseQuery: 'MacBook Pro 14 M4 Pro',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-dizustu-bilgisayar',
    refNewFloorTl: 92000,
    refUsedFloorTl: 76000,
    mustContainTokens: ['pro', 'm4 pro'],
    forbidModelTokens: ['air', 'm3', 'm2', 'm1', '16'],
    variants: [
      SpecVariant(label: '24 GB / 512 GB', queryToken: '24GB 512GB', priceFactor: 1.0, requiredTokens: ['24', '512']),
      SpecVariant(label: '24 GB / 1 TB', queryToken: '24GB 1TB', priceFactor: 1.14, requiredTokens: ['24', '1tb']),
    ],
  ),
  AppleProduct(
    id: 'imac-m4',
    name: 'iMac 24" M4',
    category: AppleCategory.mac,
    akakceBaseQuery: 'Apple iMac 24 M4',
    sahibindenBaseQuery: 'iMac M4',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-masaustu',
    refNewFloorTl: 58000,
    refUsedFloorTl: 46000,
    mustContainTokens: ['imac', 'm4'],
    forbidModelTokens: ['m3', 'm1', 'mini'],
    variants: [
      SpecVariant(label: '16 GB / 256 GB', queryToken: '16GB 256GB', priceFactor: 1.0, requiredTokens: ['16', '256']),
      SpecVariant(label: '16 GB / 512 GB', queryToken: '16GB 512GB', priceFactor: 1.18, requiredTokens: ['16', '512']),
    ],
  ),
  AppleProduct(
    id: 'iphone-16-pro-max',
    name: 'iPhone 16 Pro Max',
    category: AppleCategory.iphone,
    akakceBaseQuery: 'iPhone 16 Pro Max',
    sahibindenBaseQuery: 'iPhone 16 Pro Max',
    sahibindenCategory: 'cep-telefonu-modelleri-apple-iphone',
    refNewFloorTl: 92000,
    refUsedFloorTl: 74000,
    mustContainTokens: ['16', 'pro', 'max'],
    forbidModelTokens: ['15', '14', '13', 'plus'],
    supportsTrFilter: true,
    variants: [
      SpecVariant(label: '256 GB', queryToken: '256GB', priceFactor: 1.0, requiredTokens: ['256']),
      SpecVariant(label: '512 GB', queryToken: '512GB', priceFactor: 1.14, requiredTokens: ['512']),
      SpecVariant(label: '1 TB', queryToken: '1TB', priceFactor: 1.28, requiredTokens: ['1tb']),
    ],
  ),
  AppleProduct(
    id: 'iphone-16-pro',
    name: 'iPhone 16 Pro',
    category: AppleCategory.iphone,
    akakceBaseQuery: 'iPhone 16 Pro',
    sahibindenBaseQuery: 'iPhone 16 Pro',
    sahibindenCategory: 'cep-telefonu-modelleri-apple-iphone',
    refNewFloorTl: 78000,
    refUsedFloorTl: 64000,
    mustContainTokens: ['16', 'pro'],
    forbidModelTokens: ['max', '15', '14', '13', 'plus'],
    supportsTrFilter: true,
    variants: [
      SpecVariant(label: '128 GB', queryToken: '128GB', priceFactor: 1.0, requiredTokens: ['128']),
      SpecVariant(label: '256 GB', queryToken: '256GB', priceFactor: 1.09, requiredTokens: ['256']),
      SpecVariant(label: '512 GB', queryToken: '512GB', priceFactor: 1.24, requiredTokens: ['512']),
    ],
  ),
  AppleProduct(
    id: 'iphone-16',
    name: 'iPhone 16',
    category: AppleCategory.iphone,
    akakceBaseQuery: 'iPhone 16',
    sahibindenBaseQuery: 'iPhone 16',
    sahibindenCategory: 'cep-telefonu-modelleri-apple-iphone',
    refNewFloorTl: 58000,
    refUsedFloorTl: 46000,
    mustContainTokens: ['iphone', '16'],
    forbidModelTokens: ['pro', 'max', 'plus', '16e', '15', '14'],
    supportsTrFilter: true,
    variants: [
      SpecVariant(label: '128 GB', queryToken: '128GB', priceFactor: 1.0, requiredTokens: ['128']),
      SpecVariant(label: '256 GB', queryToken: '256GB', priceFactor: 1.12, requiredTokens: ['256']),
    ],
  ),
  AppleProduct(
    id: 'iphone-16e',
    name: 'iPhone 16e',
    category: AppleCategory.iphone,
    akakceBaseQuery: 'iPhone 16e',
    sahibindenBaseQuery: 'iPhone 16e',
    sahibindenCategory: 'cep-telefonu-modelleri-apple-iphone',
    refNewFloorTl: 44000,
    refUsedFloorTl: 35000,
    mustContainTokens: ['16e'],
    forbidModelTokens: ['pro', 'max', 'plus'],
    supportsTrFilter: true,
    variants: [
      SpecVariant(label: '128 GB', queryToken: '128GB', priceFactor: 1.0, requiredTokens: ['128']),
      SpecVariant(label: '256 GB', queryToken: '256GB', priceFactor: 1.12, requiredTokens: ['256']),
    ],
  ),
  AppleProduct(
    id: 'iphone-15-pro-max',
    name: 'iPhone 15 Pro Max',
    category: AppleCategory.iphone,
    akakceBaseQuery: 'iPhone 15 Pro Max',
    sahibindenBaseQuery: 'iPhone 15 Pro Max',
    sahibindenCategory: 'cep-telefonu-modelleri-apple-iphone',
    refNewFloorTl: 78000,
    refUsedFloorTl: 58000,
    mustContainTokens: ['15', 'pro', 'max'],
    forbidModelTokens: ['16', '14', '13', 'plus'],
    supportsTrFilter: true,
    variants: [
      SpecVariant(label: '256 GB', queryToken: '256GB', priceFactor: 1.0, requiredTokens: ['256']),
      SpecVariant(label: '512 GB', queryToken: '512GB', priceFactor: 1.14, requiredTokens: ['512']),
    ],
  ),
  AppleProduct(
    id: 'iphone-15-pro',
    name: 'iPhone 15 Pro',
    category: AppleCategory.iphone,
    akakceBaseQuery: 'iPhone 15 Pro',
    sahibindenBaseQuery: 'iPhone 15 Pro',
    sahibindenCategory: 'cep-telefonu-modelleri-apple-iphone',
    refNewFloorTl: 68000,
    refUsedFloorTl: 50000,
    mustContainTokens: ['15', 'pro'],
    forbidModelTokens: ['max', '16', '14', '13', 'plus'],
    supportsTrFilter: true,
    variants: [
      SpecVariant(label: '128 GB', queryToken: '128GB', priceFactor: 1.0, requiredTokens: ['128']),
      SpecVariant(label: '256 GB', queryToken: '256GB', priceFactor: 1.09, requiredTokens: ['256']),
    ],
  ),
  AppleProduct(
    id: 'iphone-15',
    name: 'iPhone 15',
    category: AppleCategory.iphone,
    akakceBaseQuery: 'iPhone 15',
    sahibindenBaseQuery: 'iPhone 15',
    sahibindenCategory: 'cep-telefonu-modelleri-apple-iphone',
    refNewFloorTl: 50000,
    refUsedFloorTl: 38000,
    mustContainTokens: ['iphone', '15'],
    forbidModelTokens: ['pro', 'max', 'plus', '16', '14'],
    supportsTrFilter: true,
    variants: [
      SpecVariant(label: '128 GB', queryToken: '128GB', priceFactor: 1.0, requiredTokens: ['128']),
      SpecVariant(label: '256 GB', queryToken: '256GB', priceFactor: 1.12, requiredTokens: ['256']),
    ],
  ),
  AppleProduct(
    id: 'iphone-14',
    name: 'iPhone 14',
    category: AppleCategory.iphone,
    akakceBaseQuery: 'iPhone 14',
    sahibindenBaseQuery: 'iPhone 14',
    sahibindenCategory: 'cep-telefonu-modelleri-apple-iphone',
    refNewFloorTl: 42000,
    refUsedFloorTl: 30000,
    mustContainTokens: ['iphone', '14'],
    forbidModelTokens: ['pro', 'max', 'plus', '15', '13'],
    supportsTrFilter: true,
    variants: [
      SpecVariant(label: '128 GB', queryToken: '128GB', priceFactor: 1.0, requiredTokens: ['128']),
      SpecVariant(label: '256 GB', queryToken: '256GB', priceFactor: 1.12, requiredTokens: ['256']),
    ],
  ),
  AppleProduct(
    id: 'iphone-13',
    name: 'iPhone 13',
    category: AppleCategory.iphone,
    akakceBaseQuery: 'iPhone 13',
    sahibindenBaseQuery: 'iPhone 13',
    sahibindenCategory: 'cep-telefonu-modelleri-apple-iphone',
    refNewFloorTl: 33000,
    refUsedFloorTl: 23500,
    mustContainTokens: ['iphone', '13'],
    forbidModelTokens: ['pro', 'max', 'mini', '14', '12'],
    supportsTrFilter: true,
    variants: [
      SpecVariant(label: '128 GB', queryToken: '128GB', priceFactor: 1.0, requiredTokens: ['128']),
      SpecVariant(label: '256 GB', queryToken: '256GB', priceFactor: 1.12, requiredTokens: ['256']),
    ],
  ),
  AppleProduct(
    id: 'ipad-pro-m4-11',
    name: 'iPad Pro 11" M4',
    category: AppleCategory.ipad,
    akakceBaseQuery: 'iPad Pro 11 M4',
    sahibindenBaseQuery: 'iPad Pro M4 11',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-tablet',
    refNewFloorTl: 44000,
    refUsedFloorTl: 35000,
    mustContainTokens: ['ipad', 'pro', 'm4'],
    forbidModelTokens: ['air', 'mini', '13', 'm2', 'm1'],
    variants: [
      SpecVariant(label: '256 GB Wi-Fi', queryToken: '256GB', priceFactor: 1.0, requiredTokens: ['256']),
      SpecVariant(label: '512 GB Wi-Fi', queryToken: '512GB', priceFactor: 1.22, requiredTokens: ['512']),
    ],
  ),
  AppleProduct(
    id: 'ipad-air-m3',
    name: 'iPad Air 11" M3',
    category: AppleCategory.ipad,
    akakceBaseQuery: 'iPad Air M3 11',
    sahibindenBaseQuery: 'iPad Air M3',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-tablet',
    refNewFloorTl: 27000,
    refUsedFloorTl: 21500,
    mustContainTokens: ['ipad', 'air', 'm3'],
    forbidModelTokens: ['pro', 'mini', 'm2', 'm1'],
    variants: [
      SpecVariant(label: '128 GB Wi-Fi', queryToken: '128GB', priceFactor: 1.0, requiredTokens: ['128']),
      SpecVariant(label: '256 GB Wi-Fi', queryToken: '256GB', priceFactor: 1.18, requiredTokens: ['256']),
    ],
  ),
  AppleProduct(
    id: 'ipad-10',
    name: 'iPad (A16 / 10. Nesil)',
    category: AppleCategory.ipad,
    akakceBaseQuery: 'Apple iPad 10. Nesil',
    sahibindenBaseQuery: 'iPad 10. Nesil',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-tablet',
    refNewFloorTl: 14500,
    refUsedFloorTl: 10500,
    mustContainTokens: ['ipad'],
    forbidModelTokens: ['pro', 'air', 'mini', '9. nesil', '8. nesil'],
    variants: [
      SpecVariant(label: '64 GB Wi-Fi', queryToken: '64GB', priceFactor: 1.0, requiredTokens: ['64']),
      SpecVariant(label: '128 GB / 256 GB', queryToken: '256GB', priceFactor: 1.32, requiredTokens: ['256']),
    ],
  ),
  AppleProduct(
    id: 'ipad-mini-a17',
    name: 'iPad mini (A17 Pro)',
    category: AppleCategory.ipad,
    akakceBaseQuery: 'iPad mini A17 Pro',
    sahibindenBaseQuery: 'iPad mini 7',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-bilgisayar-tablet',
    refNewFloorTl: 22000,
    refUsedFloorTl: 17500,
    mustContainTokens: ['ipad', 'mini'],
    forbidModelTokens: ['pro', 'air', 'mini 5'],
    variants: [
      SpecVariant(label: '128 GB Wi-Fi', queryToken: '128GB', priceFactor: 1.0, requiredTokens: ['128']),
      SpecVariant(label: '256 GB Wi-Fi', queryToken: '256GB', priceFactor: 1.2, requiredTokens: ['256']),
    ],
  ),
  AppleProduct(
    id: 'watch-ultra-2',
    name: 'Apple Watch Ultra 2',
    category: AppleCategory.watch,
    akakceBaseQuery: 'Apple Watch Ultra 2',
    sahibindenBaseQuery: 'Apple Watch Ultra 2',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-saat-akilli-saat',
    refNewFloorTl: 36000,
    refUsedFloorTl: 26000,
    mustContainTokens: ['watch', 'ultra', '2'],
    forbidModelTokens: ['series', 'se', 'ultra 1'],
    variants: [
      SpecVariant(label: '49 mm Titanyum', queryToken: '49mm', priceFactor: 1.0, requiredTokens: []),
    ],
  ),
  AppleProduct(
    id: 'watch-s10',
    name: 'Apple Watch Series 10',
    category: AppleCategory.watch,
    akakceBaseQuery: 'Apple Watch Series 10',
    sahibindenBaseQuery: 'Apple Watch Series 10',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-saat-akilli-saat',
    refNewFloorTl: 16500,
    refUsedFloorTl: 12000,
    mustContainTokens: ['watch', '10'],
    forbidModelTokens: ['ultra', 'se', 'series 9', 'series 8'],
    variants: [
      SpecVariant(label: '42 mm GPS', queryToken: '42mm', priceFactor: 1.0, requiredTokens: ['42']),
      SpecVariant(label: '46 mm GPS', queryToken: '46mm', priceFactor: 1.08, requiredTokens: ['46']),
    ],
  ),
  AppleProduct(
    id: 'watch-se-2',
    name: 'Apple Watch SE 2',
    category: AppleCategory.watch,
    akakceBaseQuery: 'Apple Watch SE 2',
    sahibindenBaseQuery: 'Apple Watch SE 2',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-saat-akilli-saat',
    refNewFloorTl: 9500,
    refUsedFloorTl: 6500,
    mustContainTokens: ['watch', 'se'],
    forbidModelTokens: ['ultra', 'series 10', 'series 9'],
    variants: [
      SpecVariant(label: '40 mm GPS', queryToken: '40mm', priceFactor: 1.0, requiredTokens: ['40']),
      SpecVariant(label: '44 mm GPS', queryToken: '44mm', priceFactor: 1.1, requiredTokens: ['44']),
    ],
  ),
  AppleProduct(
    id: 'airpods-pro-2',
    name: 'AirPods Pro 2 (USB-C)',
    category: AppleCategory.airpods,
    akakceBaseQuery: 'Apple AirPods Pro 2 USB-C',
    sahibindenBaseQuery: 'AirPods Pro 2',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-cep-telefonu-aksesuar-kulaklik',
    refNewFloorTl: 8800,
    refUsedFloorTl: 5800,
    mustContainTokens: ['airpods', 'pro'],
    forbidModelTokens: ['max', 'airpods 4', 'airpods 3'],
    variants: [
      SpecVariant(label: 'USB-C MagSafe', queryToken: 'USB-C', priceFactor: 1.0, requiredTokens: []),
    ],
  ),
  AppleProduct(
    id: 'airpods-4-anc',
    name: 'AirPods 4 (ANC)',
    category: AppleCategory.airpods,
    akakceBaseQuery: 'Apple AirPods 4 ANC',
    sahibindenBaseQuery: 'AirPods 4 ANC',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-cep-telefonu-aksesuar-kulaklik',
    refNewFloorTl: 6800,
    refUsedFloorTl: 4600,
    mustContainTokens: ['airpods', '4'],
    forbidModelTokens: ['pro', 'max', 'airpods 3'],
    variants: [
      SpecVariant(label: 'Aktif Gürültü Engelleme', queryToken: 'ANC', priceFactor: 1.0, requiredTokens: []),
    ],
  ),
  AppleProduct(
    id: 'airpods-max-usbc',
    name: 'AirPods Max (USB-C)',
    category: AppleCategory.airpods,
    akakceBaseQuery: 'Apple AirPods Max USB-C',
    sahibindenBaseQuery: 'AirPods Max',
    sahibindenCategory: 'ikinci-el-ve-sifir-alisveris-cep-telefonu-aksesuar-kulaklik',
    refNewFloorTl: 22500,
    refUsedFloorTl: 15500,
    mustContainTokens: ['airpods', 'max'],
    forbidModelTokens: ['pro', 'airpods 4'],
    variants: [
      SpecVariant(label: 'USB-C', queryToken: 'USB-C', priceFactor: 1.0, requiredTokens: []),
    ],
  ),
];
