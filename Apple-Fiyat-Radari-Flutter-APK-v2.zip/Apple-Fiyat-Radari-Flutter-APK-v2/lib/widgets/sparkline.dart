import 'package:flutter/material.dart';
import '../services/history_store.dart';

class PriceSparkline extends StatelessWidget {
  final List<PricePoint> points;
  final bool isDark;

  const PriceSparkline({
    super.key,
    required this.points,
    required this.isDark,
  });

  @override
  Widget build(BuildContext context) {
    final muted = isDark ? const Color(0xFF7D8596) : const Color(0xFF6E6E73);
    if (points.length < 2) {
      return SizedBox(
        height: 28,
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            points.isEmpty
                ? '30G grafik: canlı tarama bekleniyor'
                : '30G grafik: ilk kayıt alındı',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(fontSize: 10, color: muted),
          ),
        ),
      );
    }

    final first = points.first.priceTl;
    final last = points.last.priceTl;
    final isDown = last < first;
    final lineColor = isDown
        ? const Color(0xFF34D399)
        : (isDark ? const Color(0xFF8B93A3) : const Color(0xFF6B7280));

    final minP = points.map((e) => e.priceTl).reduce((a, b) => a < b ? a : b);
    final avgP = (points.map((e) => e.priceTl).reduce((a, b) => a + b) /
            points.length)
        .round();
    final diff = last - first;
    final diffSign = diff > 0 ? '+' : '';

    return Tooltip(
      message:
          '30G En Düşük: ${_fmt(minP)} TL\n30G Ortalama: ${_fmt(avgP)} TL\nDeğişim: $diffSign${_fmt(diff)} TL',
      child: SizedBox(
        height: 28,
        width: double.infinity,
        child: CustomPaint(
          painter: _SparklinePainter(points: points, color: lineColor),
        ),
      ),
    );
  }

  static String _fmt(int n) {
    final s = n.abs().toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      final rev = s.length - i;
      buf.write(s[i]);
      if (rev > 1 && rev % 3 == 1) buf.write('.');
    }
    return n < 0 ? '-${buf.toString()}' : buf.toString();
  }
}

class _SparklinePainter extends CustomPainter {
  final List<PricePoint> points;
  final Color color;

  _SparklinePainter({required this.points, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    if (points.length < 2) return;

    final prices = points.map((e) => e.priceTl.toDouble()).toList();
    final minV = prices.reduce((a, b) => a < b ? a : b);
    final maxV = prices.reduce((a, b) => a > b ? a : b);
    final range = (maxV - minV).abs() < 1 ? 1.0 : (maxV - minV);

    final path = Path();
    for (int i = 0; i < prices.length; i++) {
      final x = (i / (prices.length - 1)) * size.width;
      final norm = (prices[i] - minV) / range;
      final y = size.height - 4 - (norm * (size.height - 8));
      if (i == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }

    final paint = Paint()
      ..color = color
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.6
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    canvas.drawPath(path, paint);

    final lastX = size.width;
    final lastNorm = (prices.last - minV) / range;
    final lastY = size.height - 4 - (lastNorm * (size.height - 8));
    canvas.drawCircle(
      Offset(lastX - 1.5, lastY),
      2.6,
      Paint()..color = color,
    );
  }

  @override
  bool shouldRepaint(covariant _SparklinePainter oldDelegate) =>
      oldDelegate.points != points || oldDelegate.color != color;
}
